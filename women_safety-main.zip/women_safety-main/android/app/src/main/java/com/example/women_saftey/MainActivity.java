package com.example.women_saftey;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
